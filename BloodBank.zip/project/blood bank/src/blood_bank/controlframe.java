
package blood_bank;


public class controlframe {
    
    public void decideloginpanel(properties p)
    {           
          int A=p.getLogintype();     
          if(A==1)
          {
                   donor_panel r=new donor_panel();
                   donor_panel r1=new donor_panel(p);
                   r.setVisible(true);
                   login l=new login();
                   l.setVisible(false);
          } 
          else if(A==2)
          {
                   receiver_panel r=new receiver_panel();
                   receiver_panel r1=new receiver_panel(p);
                   r.setVisible(true);
                   login l1=new login();
                   l1.setVisible(false);
          }
          
    }
}
