
package blood_bank;


public class BloodBank {

    public static void main(String[] args) {
     login d=new login();
     d.setVisible(true);
     
    }

    

}
