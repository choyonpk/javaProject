
package blood_bank;

import java.sql.*;


public class databaseConnection {
        Connection con;
	Statement st;
	ResultSet rs;
	
	public databaseConnection()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/blood_bank", "root", "");
			st = con.createStatement();
                       
                        
		}
		catch(Exception e){System.out.println(e.getMessage());}
	}

	public void closeConnection()
	{
		try
		{
			con.close();
			st.close();
			rs.close();
		}
		catch(Exception e){System.out.println(e.getMessage());}
	}
	
}
