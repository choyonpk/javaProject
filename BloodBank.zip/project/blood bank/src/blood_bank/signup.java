
package blood_bank;
import java.lang.reflect.Method;
import javax.swing.JOptionPane;
public class signup {
        
    databaseConnection mydb=new databaseConnection();
    public signup()
            { 
               
            }
       
    public signup(properties p)
    {   
 
        try {        
	    String sql= "insert into  login(name,password,type,phone,address,gender,bloodgroup,logintype,email) VALUES ('"+p.getName()+"','"+p.getPassword()+"','"+p.getType()+"','"+p.getPhn()+"','"+p.getAdd()+"','"+p.getGender()+"','"+p.getBldgrp()+"','"+p.getLogintype()+"','"+p.getEmail()+"');";		
            mydb.st.executeUpdate(sql);
            
            
           
        }
        catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("error while insrting: "+e);           
        }
    }
      
    public void getUserid(properties p)
        {
            
        try{registration r=new registration();
            String sql= "select userid from login where name='"+p.getName()+"' and password='"+p.getPassword()+"' and type='"+p.getType()+"' and phone='"+p.getPhn()+"' and address='"+p.getAdd()+"' and gender='"+p.getGender()+"' and bloodgroup='"+p.getBldgrp()+"' and logintype='"+p.getLogintype()+"'";
            mydb.rs=mydb.st.executeQuery(sql);
            
           if(mydb.rs.next())
           { 
             int A=mydb.rs.getInt("userid");
             
             p.setUserid(A);
           }
         }
        catch(Exception e)
        {
             System.out.println("error while giving userid: "+e); 
        }
        }
        
    public void loginvalidation(String uid,String pass)   
    {
        try {       
            
			String sql= "select * from login where userid='"+uid+"' and password='"+pass+"'"; 	
    
            mydb.rs=mydb.st.executeQuery(sql);
            
            if(mydb.rs.next())
            {
                properties p=new properties();
                p.setAdd("address");
                p.setAge("age");
                p.setBldgrp("bloodgroup");
                p.setEmail("email");
                p.setGender("gender");
                p.setName("name");
                p.setPhn("phone");
                p.setType("type");
                p.setLogintype(mydb.rs.getInt("logintype"));
                p.setUserid(mydb.rs.getInt("userid"));
                
 int A=p.getLogintype();     
          if(A==1)
          {
                   donor_panel r=new donor_panel();
                   r.setVisible(true);
                   r.receiveallinfo(p);
          } 
          else if(A==2)
          {
                   receiver_panel r=new receiver_panel();
                   r.setVisible(true);
                   
          }
    
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Login failed!","Failed!!",
                                        JOptionPane.ERROR_MESSAGE);
            }
        }
        catch (Exception e) 
        {
            // TODO Auto-generated catch block
            System.out.println("error while validating: "+e);
          
        }
    }
    
}
   

